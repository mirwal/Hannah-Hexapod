#include "IK.h" // Inverse Kinematik (IK)
#include <Arduino.h>
#include <math.h>
#include <cmath>
#include <cstdint>
#include "IK.h"
#include <algorithm> // for std::clamp

static float toRad(float deg) { return deg * (M_PI / 180.0f); }

void IK::getStandardPose(float &coxa, float &femur, float &tibia)
{
    coxa = 150.0f;  // Standard-Coxa-Winkel
    femur = 150.0f; // Standard-Femur-Winkel
    tibia = 150.0f; // Standard-Tibia-Winkel
}

void IK::compute(

    uint8_t i, // 1️⃣ Index des Beins (0…5), für das gerade die IK gerechnet wird.

    float &outCoxa,  // 2️⃣ Referenz auf die Variable, in die der berechnete Coxa-Winkel (Servo 1) geschrieben wird.
    float &outFemur, // 3️⃣ Referenz auf die Variable, in die der berechnete Femur-Winkel (Servo 2) geschrieben wird.
    float &outTibia, // 4️⃣ Referenz auf die Variable, in die der berechnete Tibia-Winkel (Servo 3) geschrieben wird.

    float t, // 5️⃣ Laufzeit in Sekunden (z.B. millis()/1000.0f). Dient zur Bestimmung der Gang-Phase.

    float dirX, // 6️⃣ Normierte Richtungs-Komponente X ∈ [–1,1] (Joystick oder Tasteneingabe für vor/zurück).
    float dirY, // 7️⃣ Normierte Richtungs-Komponente Y ∈ [–1,1] (Joystick oder Tasteneingabe für seitwärts).

    float rotation // 8️⃣ (Optional) Dreh-Komponente ∈ [–1,1], wenn du das ganze Chassis um die Z-Achse rotieren lassen willst.

)
{
    // 1) Richtung und Magnitude Joystick-Vektor
    // Die Funktion hypot(dirX, dirY) gibt die Quadratwurzel der Summe der Quadrate von x und y zurück (gemäß dem Satz des Pythagoras), ohne dass es zu einem übermäßigen Über- oder Unterlauf von Zwischenwerten kommt.
    float mag = std::hypot(dirX, dirY);

    // ux und uy sind die normierten Richtungs-Komponenten, die den Bewegungsvektor repräsentieren. DEADZONE ist ein Schwellwert, unter dem die Bewegung ignoriert wird.
    float ux = (mag < DEADZONE) ? 0.0f : dirX / mag;
    float uy = (mag < DEADZONE) ? 0.0f : dirY / mag;

    // 2) Coxa-Achse (Mount)  Mount-Punkt im Body-Frame und Basis-Fußpunkt (Home) relativ zur Coxa-Achse
    float ca = mountPhi[i]; // i * 60° in Rad (bogenmaß)
    // alt// Vec3 mount = {R * std::cos(ca), R * std::sin(ca), 0.0f};
    Vec3 mount = mountPos[i]; // vordefinierte Coxa-Achsen-Position
    // Basis-Fußpunkt = Mount + Home-Offset relativ zur Coxa
    Vec3 base = mount + homeOffset[i];

    // 3) Home-Pose (keine Bewegung, nur Basis-Fußpunkt wenn mag < DEADZONE)
    if (mag < DEADZONE)
    {
        // 3a) Fußziel im Körperrahmen = einfach der Basis-Punkt
        Vec3 pB = base;

        // 3b) In Lokales Bein-Koordinatensystem transformieren
        Vec3 rel = pB - mount;
        float lx = std::cos(ca) * rel.x + std::sin(ca) * rel.y;
        float ly = -std::sin(ca) * rel.x + std::cos(ca) * rel.y;

        float lz = rel.z;

        float dx = lx - COXA_LEN; // Abstand von Coxa-Achse in X
        float d = std::sqrt(dx * dx + lz * lz);

        // Coxa
        outCoxa = std::atan2(ly, lx) * 180.0f / M_PI; // Winkel für Coxa in Grad

        // Femur
        float a1 = std::atan2(lz, dx);
        float a2 = 0.0f;
        if (d > 1e-3f)
        {
            float cosArg = (FEMUR_LEN * FEMUR_LEN + d * d - TIBIA_LEN * TIBIA_LEN) / (2.0f * FEMUR_LEN * d); // Kosinussatz für den Winkel a2
            cosArg = std::clamp(cosArg, -1.0f, 1.0f);                                                        // sicherstellen, dass cosArg im gültigen Bereich liegt... Guard auf kleine Distanzen (d oder proj > 1e-3f) – um Division durch Null zu verhindern.
            a2 = std::acos(cosArg);                                                                          // Arcus-Kosinus für den Winkel a2
        }
        outFemur = (a1 + a2) * 180.0f / M_PI; // Winkel für Femur in Grad

        // Tibia
        float a3 = 0.0f;
        if (d > 1e-3f)
        {
            float cosArgT = (FEMUR_LEN * FEMUR_LEN + TIBIA_LEN * TIBIA_LEN - d * d) / (2.0f * FEMUR_LEN * TIBIA_LEN); // Kosinussatz für den Winkel a3
            cosArgT = std::clamp(cosArgT, -1.0f, 1.0f);                                                               // sicherstellen, dass cosArgT im gültigen Bereich liegt
            a3 = std::acos(cosArgT);                                                                                  // Arcus-Kosinus für den Winkel a3
        }
        outTibia = a3 * 180.0f / M_PI; // Winkel für Tibia in Grad

        // ** letzte Sicherheits-Prüfung auf NaN **
        if (std::isnan(outFemur))
            outFemur = 150.0f; // z.B. Home-Winkel
        if (std::isnan(outTibia))
            outTibia = 150.0f; // z.B. Home-Winkel

        return;
    }

    // 4) Schrittweite & Gangzyklus
    float L = L_MAX * mag;
    float T = T_MAX - mag * (T_MAX - T_MIN);
    float phase = std::fmod(t, T) / T;

    // 5) Tripod-Gang-Phase
    bool isA = (i % 2 == 0);
    bool swing = (phase < 0.5f && isA) || (phase >= 0.5f && !isA);
    float legP = swing
                     ? ((phase < 0.5f ? phase * 2.0f : (phase - 0.5f) * 2.0f))
                     : (1.0f - (phase < 0.5f ? phase * 2.0f : (phase - 0.5f) * 2.0f));

    // 6) Schritt-Offset relativ zur Home-Position
    Vec3 stepOffset{0.0f, 0.0f, 0.0f};
    if (swing)
    {
        float s = 0.5f * (1.0f - std::cos(2 * M_PI * legP));
        stepOffset = Vec3{
            -ux * L * s,
            -uy * L * s,
            LIFT_H * static_cast<float>(std::sin(M_PI * legP))};
    }
    else
    {
        stepOffset = Vec3{
            -ux * L * legP,
            -uy * L * legP,
            0.0f};
    }

    // 7) absolutes Fußziel im Körperrahmen
    Vec3 pB = base + stepOffset;

    // 8) in lokales Bein-Koordinatensystem transformieren (Rotation um Coxa-Achse)
    Vec3 rel = pB - mount; //  Vektor relativ zur Coxa‐Achse
    float lx = std::cos(ca) * rel.x + std::sin(ca) * rel.y;
    float ly = -std::sin(ca) * rel.x + std::cos(ca) * rel.y;
    float lz = rel.z;
    Serial.printf("lx: %.2f, ly: %.2f, lz: %.2f\n", lx, rel.y, rel.z);

    // 9) IK lösen
    outCoxa = std::atan2(ly, lx) * 180.0f / M_PI;
    // projizieren auf Sagittal-Ebene (XZ) und Längen berechnen
    float dx = lx - COXA_LEN;                      // Abstand von Coxa-Achse in X
    float proj = std::sqrt((dx * dx) + (lz * lz)); // projizierte Länge auf XZ-Ebene

    float a1 = std::atan2(lz, dx); // Winkel zwischen X-Achse und projiziertem Vektor

    float a2 = 0.0f; // proj zu klein → Fuß direkt unter Femur-Gelenk... setze a2 auf 0 oder auf einen Grenzwert
    if (proj > 1e-6f)
    {
        // Kosinussatz für den Winkel a2
        float cosArg = (FEMUR_LEN * FEMUR_LEN + proj * proj - TIBIA_LEN * TIBIA_LEN) / (2.0f * FEMUR_LEN * proj);
        cosArg = std::clamp(cosArg, -1.0f, 1.0f);
        a2 = std::acos(cosArg);
    }

    outFemur = (a1 + a2) * 180.0f / M_PI; // Winkel für Femur

    // Winkel für Tibia
    float a3 = 0.0f;
    if (proj > 1e-3f)
    {
        float cosArgT = (FEMUR_LEN * FEMUR_LEN + TIBIA_LEN * TIBIA_LEN - proj * proj) / (2.0f * FEMUR_LEN * TIBIA_LEN);
        cosArgT = std::clamp(cosArgT, -1.0f, 1.0f);
        a3 = std::acos(cosArgT);
    }
    outTibia = a3 * 180.0f / M_PI; // Winkel für Tibia
}

void IK::solveLegIK(const Vec3 &pK, float mountAngle,
                    float &outCoxa, float &outFemur, float &outTibia)
{
    // 1) ins lokale Bein-Koordinatensystem rotieren
    float ca = mountAngle;
    float lx = cos(ca) * pK.x + sin(ca) * pK.y;
    float ly = -sin(ca) * pK.x + cos(ca) * pK.y;
    float lz = pK.z;

    // 2) Coxa
    outCoxa = std::atan2(ly, lx) * 180.0f / M_PI;

    // 3) projizieren auf Sagittal-Ebene (XZ) und Längen berechnen
    float dx = lx - COXA_LEN;
    float d = std::sqrt(dx * dx + lz * lz);

    // 4) Winkel per Kosinussatz
    float alpha = std::atan2(lz, dx);
    float beta = std::acos((FEMUR_LEN * FEMUR_LEN + d * d - TIBIA_LEN * TIBIA_LEN) / (2 * FEMUR_LEN * d));
    outFemur = (alpha + beta) * 180.0f / M_PI;

    outTibia = std::acos((FEMUR_LEN * FEMUR_LEN + TIBIA_LEN * TIBIA_LEN - d * d) / (2 * FEMUR_LEN * TIBIA_LEN)) * 180.0f / M_PI;
}

// Key-Points:
//     mountPos[i] ist die absolute Position deiner Coxa-Achse im Roboter-Körperrahmen.
//     homeOffset[i] ist der Vektor von dieser Coxa-Achse zur Fußspitze in Ruhe (Home).
//     base = mountPos[i] + homeOffset[i] liefert die absolute Home-Position der Fußspitze.
//     Alle weiteren Schritte (Home-IK oder Schritt-Offset) bauen immer auf diesem base auf.
//     Vor der IK-Transformation ins lokale Bein-Koordinatensystem wird immer mount subtrahiert, damit der 2D-Solver nur mit relativen Werten rechnet.