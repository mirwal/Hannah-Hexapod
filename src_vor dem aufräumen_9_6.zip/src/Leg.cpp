// Leg.cpp
#include <Arduino.h>

#include "ServoBus.h"
#include "Leg.h"

Leg::Leg(uint8_t idCoxa, uint8_t idFemur, uint8_t idTibia)
    : coxaID(idCoxa), femurID(idFemur), tibiaID(idTibia),
      angleCoxa(145), angleFemur(90), angleTibia(90),
      offsetCoxa(0.0f), offsetFemur(0.0f), offsetTibia(0.0f) {}

void Leg::setAngles(float coxaAngle, float femurAngle, float tibiaAngle)
{

    angleCoxa = 150.0f + coxaAngle + offsetCoxa;
    angleFemur = 60.0f + femurAngle + offsetFemur;
    angleTibia = 150.0f + tibiaAngle + offsetTibia;
    // speichere die gerade verteilten Soll-Werte
    targetCoxa = angleCoxa;
    targetFemur = angleFemur;
    targetTibia = angleTibia;
    ready = false; //  Flag, dass das Bein bereit ist
}

void Leg::getAngles(float &coxa, float &femur, float &tibia) const
{
    coxa = angleCoxa;
    femur = angleFemur;
    tibia = angleTibia;
}
void Leg::setAngleByID(uint8_t id, float angle)
{
    Serial.print("Set angle for ID ");
    if (id == coxaID)
        angleCoxa = angle + offsetCoxa;
    else if (id == femurID)
        angleFemur = angle + offsetFemur;
    else if (id == tibiaID)
        angleTibia = angle + offsetTibia;
}

uint8_t Leg::getID_Coxa() const
{
    return coxaID;
}

uint8_t Leg::getID_Femur() const
{
    return femurID;
}

uint8_t Leg::getID_Tibia() const
{
    return tibiaID;
}

void Leg::setOffsets(float coxaOff, float femurOff, float tibiaOff)
{
    offsetCoxa = coxaOff;
    offsetFemur = femurOff;
    offsetTibia = tibiaOff;
}
bool Leg::hasServoID(uint8_t id) const
{
    return (id == coxaID || id == femurID || id == tibiaID);
}
// fragt die Ist-Position vom Bus ab und vergleicht mit den Targets
bool Leg::isReady(ServoBus &bus)
{
    constexpr float EPS_COXA = 2.0f; // Toleranz in Grad
    constexpr float EPS_FEMUR = 2.0f;
    constexpr float EPS_TIBIA = 2.0f;

    float cNow = bus.getPresentPosition(coxaID, 1);
    float fNow = bus.getPresentPosition(femurID, 1);
    float tNow = bus.getPresentPosition(tibiaID, 1);
    bool cReady = fabs(cNow - targetCoxa) < EPS_COXA;
    bool fReady = fabs(fNow - targetFemur) < EPS_FEMUR;
    bool tReady = fabs(tNow - targetTibia) < EPS_TIBIA;
    if (coxaID == 1 || femurID == 7 || tibiaID == 13)
    {

        Serial.printf("Leg %d: cNow=%.2f, fNow=%.2f, tNow=%.2f\n",
                      coxaID, cNow, fNow, tNow);
        Serial.printf("Leg %d: targetCoxa=%.2f, targetFemur=%.2f, targetTibia=%.2f\n",
                      coxaID, targetCoxa, targetFemur, targetTibia);
        Serial.printf("Leg %d: cReady=%d, fReady=%d, tReady=%d\n",
                      coxaID, cReady, fReady, tReady);
    }

    ready = cReady && fReady && tReady;
    return ready;
}
