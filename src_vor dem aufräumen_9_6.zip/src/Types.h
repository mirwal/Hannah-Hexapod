#pragma once
#include <array>
#include <cmath>

/// Einfache 3D-Vektor-Klasse für Fuß-Positionen u.ä.
struct Vec3
{
    float x;
    float y;
    float z;
    Vec3 operator+(const Vec3 &v) const
    {
        return {x + v.x, y + v.y, z + v.z};
    }
    Vec3 operator-(const Vec3 &v) const
    {
        return {x - v.x, y - v.y, z - v.z};
    }
    Vec3 operator*(float s) const
    {
        return {x * s, y * s, z * s};
    }
};
// Coxa-Montagepunkte im Körper-Koordinatensystem
static constexpr double R = 115.0; // gemessener Abstand Motor-zu-Motor

// Präzise genug für ein regelmäßiges Sechseck:
static constexpr float HALF = 0.5f;
static constexpr float SQRT3_2 = 0.8660254037844386f; // sin(60°)

// link lengths
static constexpr float COXA_LEN = 50.0f;
static constexpr float FEMUR_LEN = 63.0f;
static constexpr float TIBIA_LEN = 96.0f;

// gait parameters
static constexpr float L_MAX = 20.0f;    // max step length [mm]
static constexpr float T_MIN = 0.2f;     // fastest cycle [s]
static constexpr float T_MAX = 1.0f;     // slowest cycle [s]
static constexpr float LIFT_H = 10.0f;   // lift height [mm]
static constexpr float DEADZONE = 0.05f; // min move magnitude

// 80 mm Abstand bei Leg0 im Winkel 60°:
//   x = 80*cos(60°) =  40.0
//   y = 80*sin(60°) =  69.28
// gerundet auf 2 Nachkommastellen

// Abstand Fußspitze ↔ Coxa-Achse = 80 mm, Z-Offset = –30 mm
#define AF_CA 80.0f // Abstand Fußspitze ↔ Coxa-Achse [mm]
static constexpr Vec3 homeOffset[6] = {
    {AF_CA, 0.0f, -30.0f},                    //  0°
    {AF_CA * HALF, AF_CA *SQRT3_2, -30.0f},   //  60°
    {-AF_CA * HALF, AF_CA *SQRT3_2, -30.0f},  // 120°
    {-AF_CA, 0.0f, -30.0f},                   // 180°
    {-AF_CA * HALF, -AF_CA *SQRT3_2, -30.0f}, // 240°
    {AF_CA * HALF, -AF_CA *SQRT3_2, -30.0f}   // 300°
};

static constexpr Vec3 mountPos[6] = {

    // R = Abstand Coxa-Achse ↔ Roboter-Mitte
    {R, 0.0f, 0.0f},                // 0°
    {R * HALF, R *SQRT3_2, 0.0f},   // 60°
    {-R * HALF, R *SQRT3_2, 0.0f},  // 120°
    {-R, 0.0f, 0.0f},               // 180°
    {-R * HALF, -R *SQRT3_2, 0.0f}, // 240°
    {R * HALF, -R *SQRT3_2, 0.0f}   // 300°
};

// Mounting-Winkel der sechs Beine (in Radiant) ohne + M_PI / 2.0f
static constexpr float mountPhi[6] = {
    0.0f,
    1 * M_PI / 3.0f,
    2 * M_PI / 3.0f,
    3 * M_PI / 3.0f,
    4 * M_PI / 3.0f,
    5 * M_PI / 3.0f};
// Home-Positionen der Füße im Körper-Koordinatensystem [mm]
// static constexpr Vec3 homePos[6] = {
//     {40.00f, 69.28f, -30.0f},   // Bein 0 (60°)
//     {80.00f, 0.00f, -30.0f},    // Bein 1 ( 0°)
//     {40.00f, -69.28f, -30.0f},  // Bein 2 (–60°)
//     {-40.00f, -69.28f, -30.0f}, // Bein 3 (–120°)
//     {-80.00f, 0.00f, -30.0f},   // Bein 4 (180°)
//     {-40.00f, 69.28f, -30.0f}   // Bein 5 (120°)

// };
