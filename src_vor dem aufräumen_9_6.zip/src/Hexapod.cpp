// Hexapod.cpp
#include <Arduino.h>
#include "Hexapod.h"
#include "ServoBus.h"
#include "Tasten.h"
#include "IK.h"
#include <cmath>

extern ServoBus servoBus;

void Hexapod::init()
{
    beine[0].setOffsets(0, 0, 0);
    beine[1].setOffsets(0, 0, 0);
    beine[2].setOffsets(0, 0, 0);
    beine[3].setOffsets(0, 0, 0);
    beine[4].setOffsets(0, 0, 0);
    beine[5].setOffsets(0, 0, 0);

    for (int i = 0; i < 6; ++i)
    {

        beine[i].setAngles(90, 90, 90);
    }
    // Bei Start einmal alle Servo-IDs durchtesten
    Serial.println("Scanning Dynamixel IDs...");
    for (uint8_t id = 1; id <= 18; ++id)
    {
        bool ok = false;
        unsigned long start = millis();
        while (!ok && millis() - start < 500)
        {

            ok = servoBus.ping(id);
        }
        if (ok)
        {
            Serial.print("Gefunden: Servo ID ");
            Serial.print(id);
            Serial.print("\t ");
            Serial.println(servoBus.getPresentPosition(id));
            servoBus.setSpeed(id, 200);
        }
        else
        {
            Serial.print("--Fehlt-: Servo ID ");
            Serial.println(id);
        }
    }
    Serial.println("Scan abgeschlossen.");
}
// ############################################################
void Hexapod::update()
{
    static bool flag_ist_offline = true;
    Tast.lesen();
    if (Tast.ist_offline())
    {

        if (flag_ist_offline)
        {

            Serial.println("Funkfernbedienung offline! ");

            for (uint8_t id = 1; id <= 18; ++id)
            {
                Serial.print(servoBus.moveSpeed(id, 312, 100));
                delay(2);
            }
        }
        flag_ist_offline = false;
    }
    else
    {
        if (!flag_ist_offline)
        {
            Serial.println("Funkfernbedienung online! ");
        }
        flag_ist_offline = true;
    }

    if (Tast.getTasteStatus(TRAINER) && !Tast.TRAINER_Flag)
    {
        for (int id = 1; id <= 18; ++id)
        {
            Serial.print(id);
            Serial.print("\t ");
            Serial.println(servoBus.getPresentPosition(id));
            int poti = constrain(Tast.getTasteWert(Poti, true), 0, 255);
            Serial.print("Poti: ");
            Serial.print(poti);
            Serial.print("\t ");
            Serial.println(servoBus.setSpeed(id, poti));

            delay(2);
        }
        Tast.TRAINER_Flag = true;
    }
    else
    {
        Tast.TRAINER_Flag = false;
    }

    // Status setzen je nach Tasten
    uint8_t tasteBits =
        (Tast.getTasteStatus(HR1) << 2) |
        (Tast.getTasteStatus(HR2) << 1) |
        (Tast.getTasteStatus(HR3) << 0);

    switch (tasteBits)
    {
    case 0b000:
        state = HexapodState::IDLE;
        break;
    case 0b100:
        state = HexapodState::TESTING;
        break;
    case 0b010:
        state = HexapodState::WALKING;
        break;
    case 0b001:
        state = HexapodState::POSING;
        break;
    default:
        state = HexapodState::IDLE;
        break;
    }

    // Je nach Status Verhalten ausführen
    switch (state)
    {
    case HexapodState::WALKING:;
        updateWalking();
        break;
    case HexapodState::TESTING:
        updateTesting();
        break;
    case HexapodState::POSING:
        updatePosing();
        break;
    case HexapodState::IDLE:
    default:
        updateIdle();
        break;
    }
    // Überprüfen, ob der Status gewechselt hat
    // Wechselerkennung:
    if (state != lastState)
    {
        lastState = state;

        switch (state)
        {
        case HexapodState::WALKING:
            Serial.println("Walking Mode");
            break;
        case HexapodState::IDLE:
            Serial.printf("Idle Mode %d", tasteBits);
            break;
        case HexapodState::TESTING:
            Serial.printf("Testing Mode %d", tasteBits);
            break;
        case HexapodState::POSING:
            Serial.printf("Posing Mode %d", tasteBits);
            break;
        default:
            // Unbekannter Modus
            Serial.printf("TasteBits: %d Mode", tasteBits);

            break;
        }
    }
}
void Hexapod::applyToServos(ServoBus &servoBus)
{
    for (int i = 0; i < 6; ++i)
    {
        // Winkel der Servos abrufen und an den ServoBus senden
        float coxa, femur, tibia;
        beine[i].getAngles(coxa, femur, tibia);
        servoBus.setPosition(beine[i].getID_Coxa(), coxa);
        servoBus.setPosition(beine[i].getID_Femur(), femur);
        servoBus.setPosition(beine[i].getID_Tibia(), tibia);
    }
}

void Hexapod::printServoIDs()
{
    Serial.println("Servo-Zuordnung:");
    for (int i = 0; i < 6; ++i)
    {
        Serial.print("Bein ");
        Serial.print(i);
        Serial.print(": ");
        Serial.print("Coxa=");
        Serial.print(beine[i].getID_Coxa());
        Serial.print(", ");
        Serial.print("Femur=");
        Serial.print(beine[i].getID_Femur());
        Serial.print(", ");
        Serial.print("Tibia=");
        Serial.println(beine[i].getID_Tibia());
    }
}
void Hexapod::updateTesting()
{
    static uint8_t testID = 1;
    static float testAngle = 65;
    static bool toggle = false;
    static unsigned long lastMove = 0;

    if (millis() - lastMove > 2000)
    {
        testAngle = toggle ? 150 : 65;

        for (int i = 0; i < 6; ++i)
        {
            if (beine[i].hasServoID(testID))
                beine[i].setAngleByID(testID, testAngle);
        }

        Serial.printf("Servo %d → %.1f\n", testID, testAngle);

        toggle = !toggle;
        if (!toggle)
            testID = (testID % 18) + 1;

        lastMove = millis();
    }
}

void Hexapod::updateWalking()
{
    // 1) Joystick einlesen und mappen
    int vz = map(Tast.getTasteWert(HL_UD), 34, 93, -64, 64);
    int sx = map(Tast.getTasteWert(HL_LR), 30, 102, -64, 64);
    int rot = map(Tast.getTasteWert(HR_LR), 29, 100, -64, 64);
    float dirX = sx / 64.0f;
    float dirY = vz / 64.0f;
    float rotation = rot / 64.0f;
    // 2) Zeit für Gangphase
    float t = millis() / 2000.0f;

    // 2) Für alle Beine: prüfen, ob ready
    bool allReady = true;
    for (int i = 0; i < 6; ++i)
    {
        if (!beine[i].isReady(servoBus))
        {
            allReady = false;
            break;
        }
    }
    // 3) Phase nur fortschalten, wenn alle Beine ready
    if (allReady)
    {
        phase += DELTA;
        if (phase >= 1.0f)
            phase -= 1.0f;
    }
    // 4) Für jedes Bein: mit genau dieser phase compute + setAngles
    for (int i = 0; i < 6; ++i)
    {
        float c, f, ti;
        //  neue IK‐Winkel berechnen
        ik.compute(i, c, f, ti, t, dirX, dirY, rotation);
        //  direkt abspeichern (und die neuen Winkel werden in isReady() später als Ziel herangezogen)
        beine[i].setAngles(c, f, ti);
    }
}

void Hexapod::updatePosing()
{
    for (int i = 0; i < 6; ++i)
    {
        float coxa, femur, tibia;
        ik.getStandardPose(coxa, femur, tibia);
        beine[i].setAngles(coxa, femur, tibia); // Posing mit versetztem Offset
    }
}

void Hexapod::updateIdle()
{
    // IDLE über die IK-Routine: dirX=dirY=rotation=0 → Home-Pose-Zweig greift
    float coxa, femur, tibia;
    for (int i = 0; i < 6; ++i)
    {
        ik.compute(
            i,     // i
            coxa,  // outCoxa
            femur, // outFemur
            tibia, // outTibia
            0.0f,  // t
            0.0f,  // dirX
            0.0f,  // dirY
            0.0f); // rotation
        beine[i].setAngles(coxa, femur, tibia);
    }
}
