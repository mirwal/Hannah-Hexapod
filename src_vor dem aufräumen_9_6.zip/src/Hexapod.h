#pragma once
#include "Leg.h"
#include "IK.h"
#include <array>
#include <stdint.h>
#include <cmath>

enum class HexapodState
{
    IDLE,
    WALKING,
    TESTING,
    POSING
    // Weitere Zustände hier ergänzen
};

class Hexapod
{
public:
    // ----- konfigurierbare Parameter -----
    float L_max = 20.0f;    // maximale Schrittweite [mm]
    float T_min = 0.2f;     // schnellste Zyklusdauer [s]
    float T_max = 1.0f;     // langsamste Zyklusdauer [s]
    float lift_h = 10.0f;   // Hubhöhe beim Swing [mm]
    float deadzone = 0.05f; // Minimum Input‐Magnitude für Bewegung
    
    
    float CYCLE_TIME = 0.5f;      // gewünschte Dauer eines vollen Zyklus
    float INTERVAL = 2.0f; // Zeitintervall für Updates [ms]
    float DELTA = INTERVAL/1000.0f / CYCLE_TIME;  



    // Start-Fußstellungen (im Körper‐Koordinatensystem)
    std::array<Vec3, 6> homePos = {{
        {-40.00f, -69.28f, -30.0f}, // Bein 0 (60°)
        {40.00f, -69.28f, -30.0f},  // Bein 1 (0°)
        {80.00f, 0.00f, -30.0f},    // Bein 3 (-60°)
        {40.00f, 69.28f, -30.0f},   // Bein 3 (-120°)
        {-40.00f, 69.28f, -30.0f},  // Bein 3 (180°)
        {-80.00f, 0.00f, -30.0f}    // Bein 3 (120°)
    }};
    // Montage-Winkel phi_i in rad (0, 60°,120°,…)
    std::array<float, 6> mountPhi = {
        0.0f + M_PI / 2.0f,
        1 * M_PI / 3.0f + M_PI / 2.0f,
        2 * M_PI / 3.0f + M_PI / 2.0f,
        3 * M_PI / 3.0f + M_PI / 2.0f,
        4 * M_PI / 3.0f + M_PI / 2.0f,
        5 * M_PI / 3.0f + M_PI / 2.0f};

    // Zeitakkumulator, aufgerufen z.B. in loop() mit deltaTime
    float t_acc = 0.0f;

    // Muss implementiert sein: löst IK und liefert coxa/femur/tibia
    struct Angles
    {
        float coxa, femur, tibia;
    };
    Angles solveIK(const Vec3 &footPosK, float mountAngle);

    // öffentlicher Aufruf: einmal pro loop()
    void updateGait(float u, float v, float dt)
    {
        // 1) Normieren & Dead-Zone
        float mag = std::hypot(u, v);
        if (mag < deadzone)
        {
            // Optional: alle Beine auf homePos zurückfahren
            return;
        }
        Vec3 d = {u / mag, v / mag, 0.0f};       // Richtungs­einheits­vektor
        float L = L_max * mag;                   // Schrittweite
        float T = T_max - mag * (T_max - T_min); // Zyklusdauer
        t_acc += dt;

        // 2) Gesamt-Phase [0,1)
        float phase = std::fmod(t_acc, T) / T;

        // 3) Für jedes Bein
        for (int i = 0; i < 6; ++i)
        {
            bool isGroupA = (i % 2 == 0); // 0,2,4 = A ; 1,3,5 = B
            bool inSwing = (phase < 0.5f && isGroupA) || (phase >= 0.5f && !isGroupA);

            // lokale Phase für Swing/Stance in [0,1]
            float legPhase;
            if (inSwing)
            {
                // Swing dauert immer T/2
                legPhase = (phase < 0.5f)
                               ? (phase * 2.0f)           // Gruppe A im ersten Halbzyklus
                               : ((phase - 0.5f) * 2.0f); // Gruppe B im zweiten
            }
            else
            {
                // Stance: von 1→0 durchlaufend
                legPhase = (phase < 0.5f)
                               ? (1.0f - phase * 2.0f)
                               : (1.0f - (phase - 0.5f) * 2.0f);
            }

            // 4) Fuß‐Sollpunkt in Körperkoordinaten
            Vec3 pK;
            if (inSwing)
            {
                // Cosinus‐Interpolation horizontal + Sinus‐Hub
                float beta = 0.5f * (1.0f - std::cos(2.0f * M_PI * legPhase));
                pK.x = homePos[i].x - d.x * L * beta;
                pK.y = homePos[i].y - d.y * L * beta;
                pK.z = homePos[i].z + lift_h * std::sin(M_PI * legPhase);
            }
            else
            {
                // Lineare Rückführung in der Standphase
                pK.x = homePos[i].x - d.x * L * legPhase;
                pK.y = homePos[i].y - d.y * L * legPhase;
                pK.z = homePos[i].z;
            }

            // 5) IK lösen und Winkel setzen
            Angles ang = solveIK(pK, mountPhi[i]);
            beine[i].setAngles(ang.coxa, ang.femur, ang.tibia);
        }
    }
    // ----- Ende konfigurierbare Parameter -----

    void init();
    void update();
    void applyToServos(class ServoBus &servoBus);
    void printServoIDs();

private:
    void updateWalking();
    void updateTesting();
    void updatePosing();
    void updateIdle();
    Leg beine[6] = {

        Leg(1, 7, 13),  // Bein 0
        Leg(2, 8, 14),  // Bein 1
        Leg(3, 9, 15),  // Bein 2
        Leg(4, 10, 16), // Bein 3
        Leg(5, 11, 17), // Bein 4
        Leg(6, 12, 18)  // Bein 5
    };
    IK ik;
    HexapodState state = HexapodState::IDLE;

    HexapodState lastState = HexapodState::IDLE;
};
static float phase = 0.0f;