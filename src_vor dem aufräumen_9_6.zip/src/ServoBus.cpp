#include "ServoBus.h"
// Control Table definitions for AX-12A (Firmware 1.0)
#define sendData(args) (Serial1.write(args)) // Write Over Serial

void ServoBus::begin()
{
    dxl.begin(1000000); // Initialisiert Serial & Direction-Pin intern!
    dxl.setPortProtocolVersion(1.0);
    Serial.println("ServoBus bereit.");
}

uint16_t ServoBus::getModelNumber(uint8_t id)
{
    return dxl.getModelNumber(id);
}

void ServoBus::setPosition(uint8_t id, float angleDeg)
{
    uint16_t posValue = (uint16_t)(angleDeg * DEG_TO_DXL); // Umrechnung von Grad in DXL-Winkel
    posValue = constrain(posValue, 0, 1023);               // stellt sicher, dass dein Wert im gültigen Dynamixel-Bereich bleibt
    // dxl.setGoalPosition(id, posValue); // einfache Bewegung, vorher gesetzte Speed bleibt erhalten
    dxl.write(id, ADDR_GOAL_POSITION_L, (uint8_t *)&posValue, 2, 10); // Set Goal Position
}

bool ServoBus::ping(uint8_t id)
{
    return dxl.ping(id);
}
float ServoBus::getPresentPosition(uint8_t id, uint8_t unit)
{
    float pos = 0.0f;
    pos = dxl.getPresentPosition(id, 0); // 0 = RAW, 1 = DEGREE

    return pos * (unit == 1 ? 300.0f / 1023.0f : 1.0f); // Umrechnung in Grad oder RAW
}
bool ServoBus::changeID(uint8_t oldID, uint8_t newID)
{
    dxl.ledOn(oldID);
    delay(1000);
    return dxl.setID(oldID, newID);
}
void ServoBus::setTorqueEnabled(uint8_t id, bool enable)
{

    uint8_t packet[8];
    packet[0] = 0xFF;
    packet[1] = 0xFF;
    packet[2] = id;
    packet[3] = 0x04; // Paketlänge ab Instruction
    packet[4] = 0x03; // WRITE Instruction
    packet[5] = 24;   // Adresse: Torque Enable
    packet[6] = enable ? 1 : 0;
    packet[7] = ~(packet[2] + packet[3] + packet[4] + packet[5] + packet[6]); // Checksum

    Serial1.write(packet, 8);
    Serial1.flush();
    delayMicroseconds(50);
}

void ServoBus::setAX12MovingSpeed(uint8_t id, uint16_t speed)
{
    uint16_t pos = 512;

    dxl.write(id, 32, (uint8_t *)&speed, 2, 10); // Set Moving Speed
    dxl.write(id, 30, (uint8_t *)&pos, 2, 10);   // ID id, Goal Position, 2 Bytes, Timeout 10ms

    // uint8_t packet[9];
    // packet[0] = 0xFF;
    // packet[1] = 0xFF;
    // packet[2] = id;
    // packet[3] = 0x05;         // Länge ab Instruction
    // packet[4] = 0x03;         // Instruction: WRITE
    // packet[5] = 32;           // Adresse: MOVING_SPEED
    // packet[6] = speed & 0xFF; // LSB
    // packet[7] = (speed >> 8); // MSB

    // // Checksumme
    // uint8_t checksum = ~(packet[2] + packet[3] + packet[4] + packet[5] + packet[6] + packet[7]);
    // packet[8] = checksum;

    // Serial1.write(packet, 9); // oder dein dynamixelBusSerial

    delayMicroseconds(TX_DELAY_TIME);
}

int ServoBus::moveSpeed(uint8_t id, uint16_t Position, uint16_t Speed)
{

    bool ok = false;
    unsigned long start = millis();
    while (!ok && millis() - start < 500)
    {
        ok = dxl.ping(id); // Ping the servo to check if it's connected
        delayMicroseconds(TX_DELAY_TIME);
    }
    dxl.write(id, ADDR_MOVING_SPEED_L, (uint8_t *)&Speed, 2, 30); // Set Moving Speed
    delayMicroseconds(TX_DELAY_TIME);
    dxl.write(id, ADDR_GOAL_POSITION_L, (uint8_t *)&Position, 2, 30); // Set Goal Position
    delayMicroseconds(TX_DELAY_TIME);

    return (0); // Return 0 if everything is ok
}
int ServoBus::setSpeed(uint8_t id, uint16_t Speed)
{

    bool ok = false;
    unsigned long start = millis();
    while (!ok && millis() - start < 500)
    {
        ok = dxl.write(id, ADDR_MOVING_SPEED_L, (uint8_t *)&Speed, 2, 30); // Set Moving Speed
        delayMicroseconds(TX_DELAY_TIME);
    }
    if (!ok)
        return (-1); // Return the read error

    return (0); // Return 0 if everything is ok
}