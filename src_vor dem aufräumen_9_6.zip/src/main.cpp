// Projekt: Hexapod Steuerung mit Teensy 4.1 und Dynamixel AX-12A

#include <Arduino.h>
#include "Hexapod.h"
#include "ServoBus.h"

#include "Tasten.h"

ServoBus servoBus;
Hexapod hexapod;
const unsigned long INTERVAL = 20; // 50 Hz
unsigned long lastUpdate = 0;

void setup()
{
  Serial.begin(115200);

  // Warten, bis die serielle Verbindung hergestellt ist
  // 3 Sekunden Timeout
  unsigned long startTime = millis();

  while (!Serial && (millis() - startTime < 3000))
  {
    delay(10);
  }

  Serial.println("Hexapod Startet...");

  Tast.begin(9600);
  servoBus.begin(); // Dynamixel UART

  hexapod.init();          // Initialposition
  hexapod.printServoIDs(); // Servos ausgeben
}

void loop()
{
  unsigned long now = millis();
  if (now - lastUpdate >= INTERVAL) // 50 Hz Zyklus
  {
    lastUpdate = now;
    hexapod.update(); // Gait/IK aktualisieren
    hexapod.applyToServos(servoBus); // Winkel an AX-12 senden
  }
}
