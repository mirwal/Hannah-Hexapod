// Leg.h
#pragma once
#include "ServoBus.h"
#include <stdint.h>

class Leg
{
public:
    Leg(uint8_t idCoxa, uint8_t idFemur, uint8_t idTibia);
    void setAngles(float coxaAngle, float femurAngle, float tibiaAngle);
    void getAngles(float &coxa, float &femur, float &tibia) const;
    uint8_t getID_Coxa() const;
    uint8_t getID_Femur() const;
    uint8_t getID_Tibia() const;
    void setOffsets(float coxaOff, float femurOff, float tibiaOff);
    bool hasServoID(uint8_t id) const; // Überprüft, ob das Bein einen bestimmten Servo-ID hat
    bool isReady(ServoBus &bus);       // Prüft, ob das Bein bereit ist
    void setAngleByID(uint8_t id, float angle);

private:
    uint8_t coxaID, femurID, tibiaID;           // Servo-IDs für Coxa, Femur und Tibia
    float angleCoxa, angleFemur, angleTibia;    // Aktuelle Winkel in Grad
    float offsetCoxa, offsetFemur, offsetTibia; // Offset-Werte
    float targetCoxa, targetFemur, targetTibia; // Zielwinkel

    bool ready = false; // Flag, ob das Bein in Bewegung ist
};