// IK.h
#pragma once
#include <cmath>
#include <cstdint>
#include "Types.h"

class IK
{
public:
    // compute full gait+IK for one leg
    // legIndex: 0..5, maps to mount angle & homePos
    // time_s: elapsed time in seconds
    // dirX, dirY: desired move direction in XY ([-1,1])
    // rotation: desired body rotation ([-1,1])
    void compute(
        uint8_t legIndex,
        float &outCoxa,
        float &outFemur,
        float &outTibia,
        float time_s,
        float dirX,
        float dirY,
        float rotation);

    // standalone pose (e.g. for IDLE/POSING)
    void getStandardPose(float &coxa, float &femur, float &tibia);

    static float mapFloat(float x, float in_min, float in_max, float out_min, float out_max)
    {
        return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
    }

    static void solveLegIK(const Vec3 &pK, float mountAngle,
                           float &outCoxa, float &outFemur, float &outTibia);
};
